import React, { useState, useRef, useEffect } from "react";
import {
  StatusBar,
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  Alert,
  Modal,
  AppState,
  ActivityIndicator,
}                                             from "react-native";
import moment                                 from "moment";
import sdk                                    from "intelli-chat-sdk";
import Toast                                  from "react-native-simple-toast";
import ImageView                              from "react-native-image-viewing";
import FontAwesome                            from 'react-native-vector-icons/FontAwesome';
import Ionicons                               from 'react-native-vector-icons/Ionicons'
import DocumentPicker                         from 'react-native-document-picker'

const Chat = props => {

  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState();
  const [interactions, setInteractions] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [imageVisible, setImageVisible] = useState(false);
  const [imageURI, setImageURI] = useState("");
  const [loadingPage, setLoadingPage] = useState(false);
  const [loading, setLoading] = useState(false);
  const [disable, setDisable] = useState(false);
  const [feedbackReceived, setFeedbackReceived] = useState(false);

  /** For unmount purpose */

  const appState = useRef(AppState.currentState);

  /** Ref */

  const scrollViewRef = useRef();

  let connectionStatus = false;

  useEffect(() => {
    (async () => {
      setLoadingPage(true);
      await JoinChat(props.user, props.appId, props.cloudServer);
    })();
    return () => {
      if (!!connectionStatus) {
        captureFeedback(null)
          .then(response => {
            connectionStatus = false;
            Toast.show("Socket disconnected");
          });
      }
    };
  }, []);

  useEffect(() => {
    const subscription = AppState.addEventListener(
      "change",
      async nextAppState => {

        if (appState.current === "docs" && nextAppState === "background") {
          return;
        }
        appState.current = nextAppState;
        if (appState.current === "background") {
          appState.current = "active";
          if (props.backAction && typeof props.backAction === "function") {
            props.backAction();
          }
          else {
            await captureFeedback(null);
          }
        }
      },
    );

    return () => {
      subscription.remove();
    };
  }, []);

  const socketCallback = async (event, data) => {

    if (event === "ready") {
      connectionStatus = true;
      await sdk.getUserInteractions(0);
      Toast.show("Connected successfully");
      setLoadingPage(false);
    }
    else if (event === "open-interactions") {
      if (data.interactions.length > 0) {
        setInteractions(data.interactions);
        await sdk.getMessages(data.interactions[0].id, 0);
      }
    }
    else if (event === "new-interaction") {
      if (data.interaction.messages.length > 0) {
        setInteractions([data.interaction]);
        data.interaction.messages.map((value, index) => {
          setMessages(curr_messages => [value]);
        });
      }
    }
    else if (event === "interaction-messages") {
      setMessages(curr_messages => [...data.messages.reverse(), ...curr_messages]);
    }
    else if (event === "new-message") {
      setMessages(curr_messages => [...curr_messages, data.message]);
    }
    else if (event === "interaction-closed") {
      if (data.interactionId) {
        await sdk.closeInteraction(data.interactionId);
      }
    }
    else if (event === "new-outbound-interaction") {
      // message and interaction payload object
    }
    else if (event === "error" || event === "auth_error") {
      Alert.alert("Alert", "Something went wrong");
    }
    else if (event === "get-feedback") {
      setModalVisible(true);
    }
  };

  const socketConnection = async (token) => {
    await sdk.connect(props.user, token, socketCallback);
  };

  /** Logout */

  const logout = async () => {
    if (!!interactions && !!interactions[0] && !!interactions[0].id) {
      await sdk.closeInteraction(interactions[0].id);
    }
    else {
      if (props.backAction && typeof props.backAction === "function") {
        props.backAction();
      }
      else {
        await captureFeedback(null);
      }
    }
  };

  /** Feedback */

  const captureFeedback = async feedback => {
    sdk
      .disconnect()
      .then(() => {
        if (!props.backAction) {
          Toast.show("Socket disconnected successfully");
        }
        setMessages([]);
        setMessage("");
        setInteractions(null);
        setModalVisible(false);
      })
      .catch(error => {
        Toast.show(error.message);
      });
  };

  /** Join Chat */

  const JoinChat = async (user, appId, cloud_server) => {

    if (!user || !user.id || !user.name || !cloud_server || !appId) {
      if (props.backAction && typeof props.backAction === "function") {
        props.backAction();
        Toast.show("Username, Unique ID,Cloud server is required");
        setLoadingPage(false);
        return;
      }
      else {
        setLoadingPage(false);
        Toast.show("Username, Unique ID,Cloud server is required");
        return;
      }
    }

    try {
      const response = await fetch(
        `${ cloud_server }/widget/${ appId }/mobile.js`,
        {
          method: "GET",
        },
      );
      const json = await response.json();
      if (json.success) {
        await socketConnection(json.token);
      }
      else {
        setLoadingPage(false);
        Toast.show("couldn't be connect");
      }
    }
    catch (error) {
      console.log("check the data ", error);
      setLoadingPage(false);
      Toast.show("couldn't be connect");
    }
  };

  const uploading = (file) => {

    setLoading(true);

    const fileToUpload = file;
    const data = new FormData();
    data.append("file", fileToUpload);

    console.log(data, "$$$$$$$$$")

    // axios.post(storeURL + "/interaction/" + interactions[0].id, data, {
    //   headers: { "Content-Type": "multipart/form-data" },
    // })
    //   .then(async function(response) {
    //     if (!!response.data && !!response.data.success) {
    //       await setMessage(response.data.url);
    //       await sendMessage(getMessageType(file), response.data.url);
    //     }
    //   })
    //   .catch(function(error) {
    //     setLoading(false);
    //     Toast.show(error.message);
    //   });
  };

  const uploadFile = async () => {
    if (messages.length <= 0) {
      return Toast.show("Please start your conversation with text");
    }
    try {
      appState.current = "docs";
      let type = DocumentPicker.types;
      const res = await DocumentPicker.pickSingle({

        type: [
          type.pdf,
          type.images,
          type.xls,
          type.xlsx,
          type.docx,
          type.doc,
          type.plainText,
        ],

        presentationStyle: "overFullScreen",
        transitionStyle: "flipHorizontal",
      });
      if (!!res && res.size < 25000000) {
        // viewImage(res);
        console.log(res)
      }
      else {
        appState.current = "background";
        Toast.show("File is too large");
      }
    }
    catch (err) {
      console.log(err)
      // if (DocumentPicker.isCancel(err)) {
      //   Toast.show("Failed to select");
      // }
      // else {
      //   alert("Unknown Error: " + JSON.stringify(err));
      // }
    }
  };
  /** Send Message */

  const sendMessage = async (type = "text", messages) => {
    if (!(!!message) && (!(!!messages))) {
      return Toast.show("Message is empty");
    }
    setLoading(true);
    if (interactions !== null) {
      await sdk.sendMessage(interactions[0].id, !!message ? message : messages, type);
    }
    else {
      await sdk.newInteraction(!!message ? message : messages, type);
    }
    setMessage("");
    setLoading(false);
  };

  /** Message Template */

  if (imageVisible) {
    return (
      <ImageView
        images={ [{ uri: imageURI }] }
        imageIndex={ 0 }
        visible={ imageVisible }
        onRequestClose={ () => {
          setImageVisible(false);
          setImageURI("");
        } }
      />
    );
  }

  const messageItem = (message, index) => {
    return (

      <View
        key={ index }
        style={ {
          alignItems: message.direction ? "flex-start" : "flex-end",
          margin: 10,
        } }>
        <View
          style={ {
            width: "80%",
            alignItems: message.direction ? "flex-start" : "flex-end",
          } }>
          <Text
            style={ {
              color: "#b3b4b5",
              fontSize: 15,
            } }>
            { message.author.name }
          </Text>
          { message.messageType
          && (message.messageType === "text")
            ? <View
              style={ {
                backgroundColor: message.direction ? "#e1e2e3" : "#BDDCF9",
                padding: 10,
                paddingHorizontal: 15,
                marginVertical: 5,
                borderBottomEndRadius: 15,
                borderBottomStartRadius: 15,
                borderTopEndRadius: message.direction ? 15 : 5,
                borderTopStartRadius: message.direction ? 5 : 15,
              } }>
              <Text style={ { color: "#3D4C61" } }>{ message.message }</Text>
            </View>


            : (message.messageType === "button" && message.attachments) ? (
                <>
                  <View
                    style={ {
                      backgroundColor: message.direction ? "#e1e2e3" : "#BDDCF9",
                      padding: 10,
                      paddingHorizontal: 15,
                      marginVertical: 5,
                      borderBottomEndRadius: 15,
                      borderBottomStartRadius: 15,
                      borderTopEndRadius: message.direction ? 15 : 5,
                      borderTopStartRadius: message.direction ? 5 : 15,
                    } }>
                    <Text style={ { color: "#3D4C61" } }>{ message.message }</Text>
                  </View>

                  { message.attachments.map((value, index) => {
                    return (
                      <TouchableOpacity
                        onPress={ () => sendMessage("text", value.data.text) }
                        key={ index }
                        style={ {
                          backgroundColor: "#24a0ed",
                          padding: 12,
                          marginVertical: 5,
                          borderRadius: 5,
                        } }>
                        <Text style={ { color: "#fff", fontWeight: "bold" } }>{ value.data.text }</Text>
                      </TouchableOpacity>
                    );
                  }) }
                </>
              )

              : message.attachments[0] && message.attachments[0].type === "image" ?
                <TouchableOpacity
                  onPress={ () => {
                    setImageVisible(true);
                    setImageURI(message.attachments[0].data.url);
                  } }>
                  <View
                    style={ {
                      height: 250,
                      width: 240,
                      borderRadius: 10, borderColor: "lightgrey", borderWidth: 5,
                    } }>
                    <Image
                      source={ { uri: message.attachments[0].data.url } }
                      style={ { height: 240, width: 230, borderRadius: 5 } }
                    />
                  </View>
                </TouchableOpacity>
                : message.attachments[0] && message.attachments[0].type === "video" ?
                  <View>
                    <Text style={ { color: "#3D4C61" } }>Unable to open video</Text>
                  </View>
                  :
                  message.attachments[0] && message.attachments[0].type === "document"
                  && (
                    <TouchableOpacity
                    >
                      <View>
                        <Text style={ { color: "#3D4C61" } }> Unable to open file</Text>
                      </View>
                    </TouchableOpacity>
                  )
          }
          <Text
            style={ {
              color: "#b3b4b5",
              fontSize: 13,
            } }>
            { moment(message.createdAt).format("D MMM h:mm A") }
          </Text>
        </View>
      </View>
    );
  };

  /** Message Loop */

  const messagesLoop = messages.map((msg, index) => {
    return messageItem(msg, index);
  });

  const onRefresh = async () => {
    if (messages.length > 0) {
      await sdk.getMessages(interactions[0].id, messages.length);
    }
  };

  return (
    <>
      { !feedbackReceived ? (
          <View style={ styles.appContainer }>
            <Modal
              animationType="slide"
              transparent={ false }
              visible={ modalVisible }
            >
              <View>
                <Text
                  style={ [
                    styles.modelHeading,
                    {
                      position: "absolute",
                      top: 20,
                      left: 20,
                      fontWeight: "bold",
                      fontSize: 25,
                    },
                  ] }>
                  Feedback
                </Text>
                <TouchableOpacity
                  style={ { position: "absolute", right: 20, top: 20 } }
                  onPress={ async e => {
                    if (props.backAction && typeof props.backAction === "function") {
                      props.backAction();
                      return;
                    }
                    await captureFeedback("good");
                  } }
                >
                </TouchableOpacity>
              </View>
              <View style={ styles.modalCenteredView }>
                <View style={ styles.modalView }>
                  <Text style={ styles.modelHeading }>
                    Please Give us your feedback before leaving the chat .
                  </Text>
                  <View>
                    <Text/>
                  </View>
                  <View>
                    <Text/>
                  </View>

                  <View>
                    <View>
                      <TouchableOpacity
                        onPress={ async e => {
                          if (props.backAction && typeof props.backAction === "function") {
                            await sdk.postFeedback(interactions[0].id, "good");
                            props.backAction();
                            setFeedbackReceived(true);
                            setModalVisible(false);
                            setMessages([]);
                            setDisable(true);
                            Toast.show("Feedback Captured successfully");
                            return;
                          }
                          await captureFeedback("good");
                        } }>
                        <View
                          style={ [
                            styles.submitButton,
                            { flexDirection: "row", justifyContent: "center" },
                          ] }>
                          <Text
                            style={ {
                              fontSize: 18,
                              fontWeight: "bold",
                              color: "white",
                              marginLeft: 10,
                            } }>
                            Good
                          </Text>
                        </View>
                      </TouchableOpacity>
                    </View>
                    <View>
                      <Text/>
                    </View>
                    <View>
                      <TouchableOpacity onPress={ async e => {
                        if (props.backAction && typeof props.backAction === "function") {
                          await sdk.postFeedback(interactions[0].id, "bad");
                          await props.backAction();
                          setFeedbackReceived(true);
                          setModalVisible(false);
                          setDisable(true);
                          setMessages([]);
                          Toast.show("Feedback Captured successfully");
                          return;
                        }
                        await captureFeedback("bad");
                      } }>
                        <View
                          style={ [
                            styles.submitButton,
                            { flexDirection: "row", justifyContent: "center" },
                          ] }>
                          {/*<FontAwesome name={ "frown" } size={ 25 } color={ "#fff" } />*/ }
                          <Text
                            style={ {
                              fontSize: 18,
                              fontWeight: "bold",
                              color: "white",
                              marginLeft: 10,
                            } }>
                            Bad
                          </Text>
                        </View>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
            </Modal>

            <Modal
              animationType="slide"
              transparent={ false }
              visible={ loadingPage }
            >
              <View style={ { flex: 1, justifyContent: "center" } }>
                <ActivityIndicator size={ 40 }/>
              </View>
            </Modal>


            <StatusBar backgroundColor="#15568C" barStyle="light-content"/>
            <View style={ styles.header }>
              { props.backAction && typeof props.backAction === "function"
                ? <View
                  style={ {
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                  } }>
                  <TouchableOpacity
                    disabled={ !!disable }
                    onPress={ () => props.backAction() }>
                    <FontAwesome name={ "arrow-left" } size={ 30 } color={ "#fff" }/>
                    {/*<Image*/ }
                    {/*  style={ { height: 40, width: 40 } }*/ }
                    {/*  source={ require("./assets/images/back.png") }/>*/ }
                  </TouchableOpacity>
                  <Text style={ styles.headerTitle }>Chat</Text>
                </View>
                :
                <Text style={ styles.headerTitle }>Chat</Text> }
              {/*<TouchableOpacity*/ }
              {/*  disabled={ !!disable }*/ }
              {/*  style={ { backgroundColor: !!disable ? "#dddddd" : "#fff", padding: 10, borderRadius: 15 } }*/ }
              {/*  onPress={ () => logout() }>*/ }
              {/*  <Text style={ { color: "#0C76C0", fontWeight: "bold" } }>Close</Text>*/ }
              {/*</TouchableOpacity>*/ }
              <TouchableOpacity
                onPress={ () => logout() }>
                <FontAwesome name={ "sign-out" } size={ 30 } color={ "#fff" }/>
              </TouchableOpacity>
            </View>

            <ScrollView
              ref={ scrollViewRef }
              onContentSizeChange={ () => {
                scrollViewRef.current.scrollToEnd({ animated: true });
              } }
              style={ { flex: 1 } }>
              { messages.length >= 20
                && <View style={ {
                  justifyContent: "center",
                  flex: 1,
                  textAlign: "center",
                  marginLeft: "auto",
                  marginRight: "auto",
                } }>
                  <TouchableOpacity
                    onPress={ onRefresh }
                    style={ [styles.submitButton, {
                      marginTop: 10,
                      width: "50%",
                      flexDirection: "row",
                      justifyContent: "space-evenly",
                    }] }>
                    {/*<FontAwesome size={ 15 } color={ "#fff" } name={ "caret-up" } />*/ }
                    <Text style={ { color: "white", textAlign: "center", fontWeight: "bold" } }>
                      Load More
                    </Text>
                  </TouchableOpacity>
                </View> }
              { messagesLoop }
            </ScrollView>
            <View
              style={ {
                backgroundColor: "#ffffff",
                borderTopWidth: 1,
                borderTopColor: "#e1e2e3",
                flexDirection: "row",
                alignItems: "center",
                paddingEnd: 10,
              } }>
              <TextInput
                style={ {
                  height: 50,
                  flex: 1,
                  paddingHorizontal: 10,
                  marginEnd: 10,
                  color: "#3D4C61",
                } }
                onChangeText={ setMessage }
                value={ message }
                placeholder="Type message here..."
                placeholderTextColor="#b3b4b5"
              />
              <TouchableOpacity
                style={ { marginRight: 10 } }
                onPress={ () => uploadFile() }>
                <FontAwesome name={ "paperclip" } color={ "black" } size={ 30 }/>
              </TouchableOpacity>
              { loading
                ? <ActivityIndicator size={ 25 } animating={ true }/>
                : <TouchableOpacity
                  onPress={ () => sendMessage() }>
                  <Ionicons name={ "send" } color={ "black" } size={ 30 }/>
                </TouchableOpacity>
              }
            </View>
          </View>)
        : <View style={ {
          height: "50%",
          justifyContent: "center",
          textAlign: "center",
          alignItems: "center",
          marginTop: "50%",
        } }>
          <Text style={ [styles.headerTitle, { color: "black" }] }>Feedback Received</Text>
        </View> }
    </>
  );
};

const styles = StyleSheet.create({
  appContainer: {
    height: "100%",
    backgroundColor: "#FAFAFA",
  },
  screenContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  input: {
    backgroundColor: "#EBEFF2",
    height: 50,
    margin: 5,
    width: 300,
    borderRadius: 25,
    color: "#525252",
    fontWeight: "bold",
    paddingLeft: 25,
    paddingRight: 25,
    textAlign: "center",
  },
  button: {
    backgroundColor: "#0C76C0",
    height: 50,
    margin: 10,
    width: 300,
    borderRadius: 25,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  buttonText: {
    color: "#ffffff",
    fontWeight: "bold",
  },
  header: {
    height: 65,
    backgroundColor: "#0C76C0",
    flexDirection: "row",
    alignItems: "center",
    paddingLeft: 20,
    paddingRight: 20,
    justifyContent: "space-between",
  },
  headerTitle: {
    color: "#ffffff",
    fontSize: 25,
    fontWeight: "bold",
    paddingLeft: 15,
  },
  ver: {
    color: "#9e9d9d",
    textAlign: "right",
    padding: 10,
  },
  modalCenteredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
    padding: 20,
  },
  modalView: {
    // backgroundColor: "#f5f5f5",
    // borderRadius: 20,
    // padding: 20,
    // margin: 10,
    // alignItems: "center",
    // shadowColor: "#000",
    // shadowOffset: {
    //   width: 0,
    //   height: 2,
    // },
    // shadowOpacity: 0.25,
    // shadowRadius: 4,
    // elevation: 5,
    // height: 300,
  },
  modelHeading: {
    fontFamily: "serif",
    color: "black",
    // fontWeight: "bold",
    fontSize: 18,
  },
  modelText: {
    color: "black",
    fontSize: 18,
  },
  modalInput: {
    // height: 150,
    // margin: 12,
    borderWidth: 1,
    textAlign: "center",
    // padding: 10,
    borderRadius: 5,
    // width: 270,
    color: "black",
  },
  submitButton: {
    alignItem: "center",
    borderRadius: 5,
    borderWidth: 1,
    fontSize: 18,
    borderColor: "#0C76C0",
    textAlign: "center",
    backgroundColor: "#0C76C0",
    padding: 10,
    fontWeight: "bold",
  },
});

export default Chat;
